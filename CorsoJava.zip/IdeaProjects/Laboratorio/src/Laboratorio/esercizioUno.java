/*Si scriva un programma che legge da tastiera un long non negativo n e lo richiede a oltranza se l'utente lo inserisse negativo.
Quindi genera n coppie (x,y) fatte da due numeri casuali di tipo double, fra -1 e 1.
Per ogni coppia controlla se la coordinata (x,y) sta dentro il cerchio di raggio 1 centrato sull'origine degli assi e in tal caso incrementa una variabile dentro di tipo long.
Alla fine stampa il valore della formula dentro * 4 / n senza perdere le cifre che seguono la virgola.
*/
package Laboratorio;
public class esercizioUno
import java.util.Random;

{
    public static void main (String[] argv)
        {
        Random random=new Random();

        for(int i=0;i< 100;i++)
            {
            int x=random.nextInt();
            double radice=Math.sqrt(x);
            //System.out.println("x = " + x + ", sqrt(" + x + ") = " + radice);
            String riga=String.format("x = %d, sqrt(%d) = %.2f\n",x,x,radice);
            System.out.println(riga);
            }
        }
    }
