Si scriva un programma che legge da tastiera un long non negativo n e lo richiede a oltranza se l'utente lo inserisse negativo.
        Quindi genera n coppie (x,y) fatte da due numeri casuali di tipo double, fra -1 e 1.
        Per ogni coppia controlla se la coordinata (x,y) sta dentro il cerchio di raggio 1 centrato sull'origine degli assi e in tal caso incrementa una variabile dentro di tipo long. Alla fine stampa il valore della formula dentro * 4 / n senza perdere le cifre che seguono la virgola.
public class Carta
{

}
