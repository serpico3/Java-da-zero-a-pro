package musica;

public class lezione {
    private final int semitone;
    public lezione(int semitone)
    {
        this.semitone = semitone;
                if(semitone < 0 || semitone > 11)
                    System.out.println("nota illegale");
    }
    public String toString()
    {
        return "nota di semitono " + semitone;
    }
    public int getSemitone()
    {
        return semitone;
    }
}
