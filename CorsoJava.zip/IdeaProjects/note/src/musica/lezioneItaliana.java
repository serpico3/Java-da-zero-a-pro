package musica;

public class lezioneItaliana extends lezione
{
    public lezioneItaliana(int semitone)
    {
       super(semitone);
    }

    private final static String[] names = {"do", "do#", "re", "re#", "mi", "mi#", "fa", "fa#", "sol", "sol#", "la", "la#", "si"};

    public String toString()
    {
        return names[getSemitone()];
    }
}
