package musica;

public class main {
    public static void main(String[] args)
    {
        lezione n1 = new lezione (3);
        lezione n2 = new lezione(11);
        System.out.println(n1);
        System.out.println(n2);
        lezioneItaliana n3 = new lezioneItaliana(4);
        System.out.println(n3);
        lezione n4 = new lezioneItaliana(5);
        System.out.println(n4.toString());
    }
}
