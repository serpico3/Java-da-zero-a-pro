package lezione_uno;

public abstract class veicolo
{
    abstract void muovi();
    abstract void frena();
}
