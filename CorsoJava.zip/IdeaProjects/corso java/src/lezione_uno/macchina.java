package lezione_uno;

public class macchina extends veicolo
{

    @Override
    void muovi()
    {
        System.out.println("muove ");
    }

    @Override
    void frena()
    {
        System.out.println("frena ");
    }
}
