package pacchetto1;

public interface preda
{
    void scappa();
}
