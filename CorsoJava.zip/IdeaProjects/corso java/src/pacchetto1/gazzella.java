package pacchetto1;

public class gazzella implements preda{
    @Override
    public void scappa() {
        System.out.println("scappa");
    }
}
