package pacchetto1;

public class leone implements predatore
{
    @Override
    public void caccia()
    {
        System.out.println("caccia");
    }
}
