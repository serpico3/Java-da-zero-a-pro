package pacchetto1;

public interface predatore
{
    void caccia();
}
