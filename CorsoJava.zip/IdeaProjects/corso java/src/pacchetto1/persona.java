package pacchetto1;

public class persona
{
    //attributi private
    private String nome;
    private String cognome;
    persona(String nome, String cognome)
    {
        this.nome = nome;
        this.cognome = cognome;
    }
    //getters
    public String getNome()
    {
        return nome;
    }
    public String getCognome()
    {
        return cognome;
    }
    //setters
    public void setNome(String nome)
    {
        this.nome = nome;
    }
    public void setCognome(String cognome)
    {
        this.cognome = cognome;
    }

    public void copy(persona persona)
    {
        this.setNome(persona.getNome());
        this.setCognome(persona.getCognome());
    }
}
