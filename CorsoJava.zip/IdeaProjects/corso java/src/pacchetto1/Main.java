package pacchetto1;

public class Main
{
    public static void main(String[] args)
    {
        //incapsulamento
        /*persona persona = new persona("Luca", "rossi");
        System.out.println(persona.getNome());
        persona.setCognome("Verdi");
        System.out.println(persona.getCognome());*/
        //copia oggetti
        /*persona persona1 = new persona("Luca", "rossi");
        persona persona2 = new persona("mario", "verdi");
        //persona2=persona1; questo copia anche le celle di memoria
        persona2.copy(persona1);
        System.out.println(persona1);
        System.out.println(persona2);
        System.out.println();
        System.out.println(persona1.getNome());
        System.out.println(persona1.getCognome());
        System.out.println();
        System.out.println(persona2.getNome());
        System.out.println(persona2.getCognome());*/
        //interfacce
        /*leone leone = new leone();
        gazzella gazzella = new gazzella();
        gazzella.scappa();
        leone.caccia();
        pesce pesce = new pesce();
        pesce.caccia();
        pesce.scappa();*/

    }

}
