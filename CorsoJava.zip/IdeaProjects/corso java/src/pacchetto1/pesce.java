package pacchetto1;

public class pesce implements predatore,preda
{

    @Override
    public void scappa()
    {
        System.out.println("pesce scappa");
    }

    @Override
    public void caccia()
    {
        System.out.println("pesce caccia");
    }
}
