package Pesce;
import java.util.Random;
import java.util.Scanner;

public class Cane {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        long n;
        do {
            System.out.print("Inserisci n: ");
            n = keyboard.nextLong();
        }
        while (n < 0);
        for (int riga = 0; riga < n; riga++) {
            for (int colonna = 0; colonna < n; colonna++) {
                if(riga==0 || riga==n-1)
                {
                    System.out.print("*");
                }
                else if(colonna==0 || colonna==n-1)
                {
                    System.out.print("*");
                }
                else
                {
                    System.out.print("o");
                }
            }
            System.out.println();
        }
    }
}
