package Pesce;

public class Cornici {
    public static void main(String[] args) {
        long n = 2;

        for(int cornice=0; cornice<10; cornice++)
        {
            for (int riga = 0; riga < n; riga++)
            {
                for (int colonna = 0; colonna < n; colonna++)
                {
                    System.out.print("*");
                }
                System.out.println();
            }
            n++;
        }
    }
}
